/* 

There are two things wrong with this line
1. The variable is invalid.  It should be `someNumber`, not `some Number`.  There is an extra space.
2. We should be using `let` here because later in the code, we re-assign the value of the variable

*/
const some Number = 20;

// 3. This line is missing a semi-colon at the end
someNumber = 50
