The lesson 6 challenges are hosted on Codewars.  Here are the relevant links:

- [Codewars Challenge Collection](https://www.codewars.com/collections/lesson-6-challenges-number-fullstackroadmap)
- [YouTube video where I solve all the challenges](https://www.youtube.com/watch?v=ijbcs0ESqoM)

Some of the challenges here are considering "intermediate" level.  You should still try them out, but if you get stuck, you can always follow along with my solutions video!