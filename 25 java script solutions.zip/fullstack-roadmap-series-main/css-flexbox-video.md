## Welcome!

If you're coming from the "Learn CSS Flexbox in 3 hours (with live coding)" video, **you're in the right place!**.

This page is a quick reference for you to find all the coding challenge solutions from the video.

## Reference

* 1:24:42 - [Frontend Mentor CSS Flexbox "Testimonials" challenge](https://github.com/zachgoll/fullstack-roadmap-series/tree/main/code-challenges/lesson-9)
