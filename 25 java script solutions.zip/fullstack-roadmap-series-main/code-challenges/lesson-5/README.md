The lesson 5 challenges are hosted on Codewars.  Here are the relevant links:

- [Codewars Challenge Collection](https://www.codewars.com/collections/lesson-5-practice-challenges-number-fullstackroadmap)
- [YouTube video where I solve all the challenges](https://www.youtube.com/watch?v=sqRk0Ly66Ps)

These challenges are pretty difficult for someone starting out, but they will advance your skills tremendously if you put the effort in!  Use whatever resources you need, but be sure to try them on your own!