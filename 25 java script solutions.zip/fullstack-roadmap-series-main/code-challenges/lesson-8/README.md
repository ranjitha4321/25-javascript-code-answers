The lesson 8 challenge is an HTML + CSS challenge (with a small amount of JavaScript for practice) from Frontend mentor.  [Here is the challenge starter link](https://www.frontendmentor.io/challenges/single-price-grid-component-5ce41129d0ff452fec5abbbc).

![preview](https://dev-to-uploads.s3.amazonaws.com/uploads/articles/jt75eqwhamskgms8mxpi.jpg)

The `solution/` folder has three solution files in it:

1. `index.html`
2. `style.css`
3. `script.js`

You can solve this challenge locally with VSCode and the Live Server extension (you'll have to do a bit of research on this), or you can solve it on Codepen.  [Here is the Codepen solution](https://codepen.io/zg_dev/pen/yLVpLPY).